package com.blog.constants;

//this is a constant class
public class ApplicationConstant {

	
	public static final String MESSAGE="message";
	
	
	public static final String REGISTRATION_SUCCESS_MSG="REGISTRATION SUCCESS";
	public static final String REGISTRATION_FAILURE_MSG="REGISTRATION FAILED";
	
	public static final String LOGIN_SUCCESS_MSG="LOGIN SUCCESS";
	public static final String LOGIN_FAILURE_MSG="LOGIN FAILED";
	
	
	
	
	
}
