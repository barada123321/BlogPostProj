package com.blog.user.model;

import lombok.Data;

@Data
public class Login {
	
	private String email;
	private String pwd;
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getPwd() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
