package com.blog.user.model;

import lombok.Data;

@Data
public class UserFormModel {
	
	private String name;
	
	private String email;
	
	private String password;

}
